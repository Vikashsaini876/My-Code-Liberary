<section id="content" class="clearfix">

	<?php 
		if( is_active_sidebar('primary') )
			echo '<div class="three_fourths">';
		
		if ( have_posts() ) : while ( have_posts() ) : the_post();
			
			get_template_part('loop/content','main');
		
		endwhile;	
		else : 
			
			get_template_part('loop/content','none');
			
		endif;
		
		echo function_exists('ebor_pagination') ? ebor_pagination() : posts_nav_link();
		
		if( is_active_sidebar('primary') ){
			echo '</div>';
			get_sidebar();
		}
	?>

</section>