<?php
	/**
	* This loop is used to create items for the portfolio archives and also the homepage template.
	* Any custom functions prefaced with ebor_ are found in /ebor_framework/theme_functions.php
	* First let's declare $post so that we can easily grab everthing needed.
	*/
	global $post;
	
	/**
	* Next, we need to grab the featured image URL of this post, so that we can trim it to the correct size for the chosen size of this post.
	*/
	$url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full');
	
	/**
	* Now let's crop the image with the aq_resize function, from the aqua resizer found at /ebor_framework/aq_resizer.php
	* We'll return an array to build the image with
	* @return array
	*/
	if( $url )
		$image = aq_resize($url[0], 630, 220, 1, false);
	
	/**
	 * Determine if we're looking at a single post or a feed, and prepend our theme options accordingly
	 */
	( is_single() ) ? $location = 'single_' : $location = 'index_';
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	
	<?php 
		the_title('<h2 class="article-title"><a href="' . get_permalink() . '">','</a></h2><div style="margin-bottom:0px;"></div>');  
?>
		<h5 class="date-title"><?php the_time(get_option('date_format')); ?></h5>
<?php
		if( get_option($location.'meta','1') == '1' )
			echo '<div class="two_thirds">';

		the_content( get_option('blog_continue', 'Continue Reading &rarr;') );
		wp_link_pages();
		
		if( is_single() )
			the_tags( __('Tags: ','ebor_starter'),', ','');
		
		if( get_option($location.'meta','1') == '1' )
			echo '</div><div class="one_third last">';

		if( get_option($location.'meta','1') == '1' ) :
	?>
			<h5 class="date-title"><?php the_time(get_option('date_format')); ?></h5>
			
			<?php if( $url) : ?>
				<a href="<?php the_permalink(); ?>" class="popup-link" data-title="<?php the_title(); ?>" data-href="<?php echo $url[0]; ?>">
					<img src="<?php echo $image[0]; ?>" alt="<?php the_title(); ?>" width="<?php echo $image[1]; ?>" height="<?php echo $image[2]; ?>" />
				</a>
			<?php endif; ?>
			
	<?php
			get_template_part('loop/content','meta');
			echo '</div><div class="clear"></div>';
			
		endif;
	?>
	
</article>