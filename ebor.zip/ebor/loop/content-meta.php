<div class="post-meta">
	<dl>
		<dt><?php _e('Author','ebor_starter'); ?>:</dt>
		<dd><ul><li><?php the_author_posts_link(); ?></li></ul></dd>
	</dl>
	<dl>
		<dt><?php _e('Category','ebor_starter'); ?>:</dt>
		<dd><?php the_category(); ?></dd>
	</dl>
	<?php  
		get_template_part('loop/loop','postnav'); 
	?>

</div>