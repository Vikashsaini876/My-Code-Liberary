<section id="content" class="clearfix">
	
	<?php 
		$i = 0;
		if ( have_posts() ) : while ( have_posts() ) : the_post();
		$i++;
	?>
		
			<div class="one_fourth <?php if( $i % 4 == 0 ) echo 'last'; ?>">
				<?php get_template_part('loop/content','portfolio'); ?>
			</div>
			
			<?php if( $i % 4 == 0 ) echo '<div class="clear"></div>'; ?>
	
	<?php
		endwhile;	
		else : 
			
			get_template_part('loop/content','none');
			
		endif;
		
		echo '<div class="clear"></div>';
		
		echo function_exists('ebor_pagination') ? ebor_pagination() : posts_nav_link();
	?>
	
	<div class="clear"></div>
	
</section>