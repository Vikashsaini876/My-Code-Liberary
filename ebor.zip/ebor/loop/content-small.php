<?php
	/**
	* This loop is used to create items for the portfolio archives and also the homepage template.
	* Any custom functions prefaced with ebor_ are found in /ebor_framework/theme_functions.php
	* First let's declare $post so that we can easily grab everthing needed.
	*/
	global $post;
	
	/**
	* Next, we need to grab the featured image URL of this post, so that we can trim it to the correct size for the chosen size of this post.
	*/
	$url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full');
	
	/**
	* Now let's crop the image with the aq_resize function, from the aqua resizer found at /ebor_framework/aq_resizer.php
	* We'll return an array to build the image with
	* @return array
	*/
	if( $url )
		$image = aq_resize($url[0], 630, 220, 1, false);
?>

<article id="portfolio-<?php the_ID(); ?>" <?php post_class(); ?>>
	
	<?php if( $url ) : ?>
		<a href="<?php the_permalink(); ?>" class="blog-index-link">
			<img src="<?php echo $image[0]; ?>" alt="<?php the_title(); ?>" width="<?php echo $image[1]; ?>" height="<?php echo $image[2]; ?>" />
			<div class="clear"></div><!--clear floats-->
		</a>
	<?php endif; ?>
	
	<?php
		the_title('<h3 class="article-title small-article-title"><a href="' . get_permalink() . '">','</a></h3>'); 
		the_excerpt();
	?>
	
</article>