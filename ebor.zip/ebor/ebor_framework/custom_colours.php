<?php 
	add_action('wp_head','ebor_custom_colours', 100);
	function ebor_custom_colours(){
	
	$heading_font = get_option('heading_font', 'Rufina');
	$body_font = get_option('body_font', 'Roboto');
	$nav_margin = get_option('nav_margin','55');
	$highlight_colour = get_option('highlight_colour', '#3498db');
	$highlight_hover_coilour = get_option('highlight_hover_colour','#2980b9');
	$page_wrapper = get_option('footer_colour','#ffffff');
	$text_colour = get_option('text_colour','#666666');
	$heading_colour = get_option('heading_text_colour','#444444');
	$meta = get_option('meta_colour','#c7c7c7');
	$heading_link = get_option('heading_link_colour','#000000');
?>
	
<style type="text/css">
	
	body, input[type="text"], input[type="submit"], textarea, .portfolio-index-title, .date-title, .widget-title, h4 span.meta, .resp-easy-accordion h2.resp-accordion {
		font-family: '<?php echo $body_font; ?>', sans-serif;
	}
	
	h1, h2, h3, h4, h5, h6 {
		font-family: '<?php echo $heading_font; ?>', sans-serif;
	}
	
	#main-nav > div {
		padding-top: <?php echo $nav_margin; ?>px;
	}
	
	a {
		color: <?php echo $highlight_colour; ?>;
	}
	
	.pagination li.active a {
		border-color: <?php echo $highlight_colour; ?>;	
		color: <?php echo $highlight_colour; ?>;
	}
	
	.wrapper, #main-nav ul ul, #main-nav ul ul li a {
		background: <?php echo $page_wrapper; ?>;
	}
	
	body {
		color: <?php echo $text_colour; ?>;
	}
	
	h1, h2, h3, h4, h5, h6, #main-nav a {
		color: <?php echo $heading_colour; ?>;
	}
	
	.wrapper, input[type="text"], input[type="email"], input[type="submit"], textarea, pre, #main-nav ul ul, #btt, img.wpcf7-form-control.wpcf7-captchac {
		border: 2px solid <?php echo $meta; ?>;
	}
	
	hr, .content-break {
		background: <?php echo $meta; ?>;
	}
	
	#sub-header, #sub-footer {
		color: <?php echo $meta; ?>;
		border-bottom: 2px solid <?php echo $meta; ?>;
                margin-bottom:20px;
	}
	
	aside .widget, .date-title {
		border-bottom: 0px solid <?php echo $meta; ?>;
	}
	
	a + .post-meta, #sub-footer, #main-footer {
		border-top: 2px solid <?php echo $meta; ?>;
	}
	
	.date-title, .widget-title, blockquote, dt, h4 span.meta, .portfolio-index-title {
		color: <?php echo $meta; ?>;
	}
	
	.pagination a, .postnav {
		border: 2px solid <?php echo $meta; ?>;
		color: <?php echo $meta; ?>;
	}
	
	table, table th, table td {
		border: 1px solid <?php echo $meta; ?>;
	}
	
	#sub-footer {
		border-bottom: none;
	}
	
	h1 a, h2 a, h3 a, h4 a, h5 a, h6 a {
		color: <?php echo $heading_link; ?>;
	}

	<?php echo get_option('custom_css'); ?>
	
</style>
	
<?php }

add_action('login_head','ebor_custom_admin');
function ebor_custom_admin(){
	if( get_option('custom_login_logo') )
		echo '<style type="text/css">
				.login h1 a { 
					background-image: url("'.get_option('custom_login_logo').'"); 
					background-size: auto 80px;
					width: 100%; 
				} 
			</style>';
}