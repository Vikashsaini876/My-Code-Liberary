<aside class="one_fourth last">
	<?php dynamic_sidebar('page'); ?>
</aside>