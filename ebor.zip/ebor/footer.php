	<?php if( is_active_sidebar('footer1') ) : ?>
	
		<footer id="main-footer">
			
			<?php
				if( is_active_sidebar('footer1') && !( is_active_sidebar('footer2') ) && !( is_active_sidebar('footer3') ) ){
					dynamic_sidebar('footer1');
				}
					
				if( is_active_sidebar('footer2') && !( is_active_sidebar('footer3') ) ){
					echo '<div class="one_half">';
						dynamic_sidebar('footer1');
					echo '</div><div class="one_half last">';
						dynamic_sidebar('footer2');
					echo '</div><div class="clear"></div>';
				}
					
				if( is_active_sidebar('footer3') ){
					echo '<div class="one_third">';
						dynamic_sidebar('footer1');
					echo '</div><div class="one_third">';
						dynamic_sidebar('footer2');
					echo '</div><div class="one_third last">';
						dynamic_sidebar('footer3');
					echo '</div><div class="clear"></div>';
				}
			?>
			
		</footer>
		
	<?php endif; ?>
	
	<footer id="sub-footer">
		<div class="floatleft">
			<?php echo wpautop(get_option('copyright', 'Configure this message in "appearance" => "customize"')); ?>
		</div>
		
		<div class="floatright">
			<div id="btt"><i class="fa fa-angle-up fa-2x"></i></div>
		</div>
		<div class="clear"></div>
		
	</footer>

</div><!--/.wrapper-->

<?php wp_footer(); ?>
</body>
</html>