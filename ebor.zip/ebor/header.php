<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<title><?php echo ( is_home() || is_front_page() ) ? bloginfo('name') : wp_title('| ', true, 'right'); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php wp_head(); ?>
<link href=" <?php echo get_template_directory_uri(); ?>/3d-falling-leaves.css" rel="stylesheet">
<script src=" <?php echo get_template_directory_uri(); ?>/3d-falling-leaves.js" type="text/javascript"></script>
<script src=" <?php echo get_template_directory_uri(); ?>/rotate3Di.js" type="text/javascript"></script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-49902323-1', 'anekamanners.com.au');
  ga('send', 'pageview');

</script>

</head>

<body <?php body_class(); ?>>

<div id="mobile-nav-bar">
	<a href="#mobile-menu">
		<i class="fa fa-bars"></i>
	</a>
</div>

<div id="huge-search">
	<?php get_search_form(); ?>
</div>

<div class="wrapper">

	
	<header id="main-header">
	
		<div class="one_third">
			<a class="brand" href="<?php echo home_url(); ?>">
				<?php if( get_option('custom_logo') ) : ?>
					<img src="<?php echo get_option('custom_logo'); ?>" alt="<?php echo get_option('custom_logo_alt_text'); ?>" class="retina" />
				<?php else : ?>
					<?php echo bloginfo('title'); ?>
				<?php endif; ?>
			</a>
		</div>
		
		<nav id="main-nav" class="two_thirds last">
			<?php
				wp_nav_menu('theme_location=primary');
			?>
		</nav>
		<div class="clear"></div><!--clear floats-->
        
        <div id="fallingleaves">
        	<!--<img alt="Aneka Manners Blog" src="/wp-content/uploads/2014/01/header-black1.jpg" width="1075" height="170" />-->
            <img alt="Aneka Manners Blog" src="/wp-content/uploads/2016/07/header-black2.jpg" width="1075" height="170" />
           
        </div>
		<script type="text/javascript">
		// <![CDATA[
			jQuery( document ).ready(function() {
         		jQuery("#fallingleaves").octoberLeaves();
			});
        // ]]>
        </script>
	
	</header>