<?php 
	get_header();
	
	global $wp_query;
	$total_results = $wp_query->found_posts;
	( $total_results == '1' ) ? $items = __('Item','ebor_starter') : $items = __('Items','ebor_starter'); 
?>
	
	<section id="content" class="clearfix">
		
		<h2>
			<?php 
				echo sprintf( __('Your Search For:','ebor_starter') . ' %s ' . __( 'Returned:', 'ebor_starter' ) . ' %s %s ', get_search_query(), $total_results, $items);
			?>
		</h2>
		<div class="content-break"></div>
		
		<?php
			if ( have_posts() ) : while ( have_posts() ) : the_post();
		?>
		
				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					
					<?php 
						the_title('<h3 class="article-title margin-bottom-10"><a href="' . get_permalink() . '">','</a></h3>');
						the_excerpt();
					?>
					<a href="<?php the_permalink(); ?>"><?php echo get_option('blog_continue', 'Continue Reading &rarr;'); ?></a>
					
				</article>
				
		<?php	
			endwhile;	
			else : 
				
				get_template_part('loop/content','none');
				
			endif;
		?>
	
	</section>

<?php	
	get_footer();