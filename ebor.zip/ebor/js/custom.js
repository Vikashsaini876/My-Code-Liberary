/*-----------------------------------------------------------------------------------*/
/*	SCROLL TO TOP OF PAGE
/*-----------------------------------------------------------------------------------*/
jQuery(document).ready(function($){
'use strict';

	$('#btt').click(function(){
		$("html, body").animate({ scrollTop: 0 }, 1200);
		return false;
	});

});
/*-----------------------------------------------------------------------------------*/
/* Navigation Functions
/*-----------------------------------------------------------------------------------*/
jQuery(document).ready(function($){
	"use strict";
	
	$('#search-link').click(function(){
		$('#huge-search').slideToggle();
		$('#huge-search input').trigger('focus');
	});
	
	$("#main-nav").clone().appendTo('#main-header').attr('id', 'mobile-menu').mmenu().find('#search-link').remove();
	
	$(window).resize(function(){
		if( $(window).width() > 959 )
			$('#mobile-menu').trigger('close.mm');
	});
	
});
/*-----------------------------------------------------------------------------------*/
/* Get rid of useless paragraphs
/*-----------------------------------------------------------------------------------*/
jQuery(document).ready(function($){
	"use strict";
	
	$("p:empty").remove();
	
});
/*-----------------------------------------------------------------------------------*/
/*	Fancy Ampersands
/*-----------------------------------------------------------------------------------*/
jQuery(document).ready(function($){
	"use strict";
	
	$("body *").replaceText( /&/gi, '<span class="amp">' + '&' + '</span>' );
	
});
/*-----------------------------------------------------------------------------------*/
/*	Lightbox
/*-----------------------------------------------------------------------------------*/
jQuery(document).ready(function($) {
	"use strict";
	
	jQuery("a[href$='jpg'], a[href$='jpeg'], a[href$='gif'], a[href$='png']").each(function(){
		$(this).attr('data-href', $(this).attr('href'));
		$(this).attr('href', '#')
	});
	
	jQuery("a[data-href$='jpg'], a[data-href$='jpeg'], a[data-href$='gif'], a[data-href$='png']").magnificPopup({
		type:'image'
	});
	
});