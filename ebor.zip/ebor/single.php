<?php 
	get_header();
	the_post();
?>

<section id="content" class="clearfix">

	<?php 
		if( is_active_sidebar('primary') && get_post_meta( $post->ID, '_ebor_disable_sidebar', true ) !=='on' )
			echo '<div class="three_fourths">';
		
		get_template_part('loop/content','main');
		
		if( comments_open() )
			comments_template();
		
		if( is_active_sidebar('primary') && get_post_meta( $post->ID, '_ebor_disable_sidebar', true ) !=='on' ){
			echo '</div>';
			get_sidebar();
		}
	?>

</section>

<?php	
	get_footer();