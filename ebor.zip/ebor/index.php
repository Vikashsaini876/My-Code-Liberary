<?php 
	get_header();
	
	get_template_part('loop/loop','main');
	
	get_footer();