<?php 
	/*
	Template Name: Homepage
	*/
	get_header();
	the_post();
?>

<section id="content" class="clearfix">
	
	<article id="page-<?php the_ID(); ?>" <?php post_class(); ?>>
	
		<?php 
			the_content(); 
			
			if( get_the_content() && get_option('homepage_portfolio', '1') == '1' || get_the_content() && get_option('homepage_blog', '1') == '1' )
				echo '<div class="content-break"></div>';
			
			/**
			 * Show Portfolio on Homepage?
			 */
			if( get_option('homepage_portfolio', '1') == '1' ) :
				
				echo '<div class="break-40"></div>';
				
				$i = 0;
				$portfolio_query = new WP_Query('post_type=portfolio&posts_per_page=4');
				if ( $portfolio_query->have_posts() ) : while ( $portfolio_query->have_posts() ) : $portfolio_query->the_post();
				$i++;
		?>
			
					<div class="one_fourth <?php if( $i % 4 == 0 ) echo 'last'; ?>">
						<?php get_template_part('loop/content','portfolio'); ?>
					</div>
		
		<?php
				endwhile;	
				else : 
					
					get_template_part('loop/content','none');
					
				endif;
				wp_reset_query();
				
				if( get_option('homepage_portfolio', '1') == '1' && get_option('homepage_blog', '1') == '1')
					echo '<div class="clear"></div><div class="content-break"></div>';
			
			endif;
			
			/**
			 * Show Blog on Homepage?
			 */
			if( get_option('homepage_blog', '1') == '1' ) :
				
				echo '<div class="break-40"></div>';
				
				$i = 0;
				$blog_query = new WP_Query('post_type=post&posts_per_page=3');
				if ( $blog_query->have_posts() ) : while ( $blog_query->have_posts() ) : $blog_query->the_post();
				$i++;
		?>
		
					<div class="one_third <?php if( $i % 3 == 0 ) echo 'last'; ?>">
						<?php get_template_part('loop/content','small'); ?>
					</div>
		
		<?php
				endwhile;	
				else : 
					
					get_template_part('loop/content','none');
					
				endif;
				wp_reset_query();
				
			endif;
		?>
	
	</article>
	
</section>

<?php	
	get_footer();