<?php 
	/*
	Template Name: Portfolio
	*/
	get_header();
	the_post();
?>

<section id="content" class="clearfix">
	
	<article id="page-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php 
$customPostTaxonomies = get_object_taxonomies('portfolio');
if(count($customPostTaxonomies) > 0)
{
     foreach($customPostTaxonomies as $tax)
     {
	     $args = array(
         	  'orderby' => 'name',
	          'show_count' => 0,
        	  'pad_counts' => 0,
	          'hierarchical' => 1,
        	  'taxonomy' => $tax,
        	  'title_li' => ''
        	);

	     $categories = get_categories($args); 
     }
}
  $i = 0;
  foreach ($categories as $category) {
  $i++;
  	/*$option = '<option value="/category/archives/'.$category->category_nicename.'">';
	$option .= $category->cat_name;
	$option .= ' ('.$category->category_count.')';
	$option .= '</option>';
	echo $option;*/
	?>
<div class="one_fourth <?php if( $i % 4 == 0 ) echo 'last'; ?>">
<?php if (function_exists('z_taxonomy_image_url')) echo z_taxonomy_image_url(); ?>
	<article id="portfolio-<?php $category->term_id ; ?>" <?php post_class(); ?>>
	<a href="/portfolio-category/<?php echo $category->slug; ?>/" class="portfolio-index-link">
		<img src="<?php echo z_taxonomy_image_url($category->term_id); ?>" width="<?php echo $image[1]; ?>" height="<?php echo $image[2]; ?>" />
		<?php echo ('<h4 class="portfolio-index-title">' . $category->cat_name . '</h4>'); ?>
		<div class="clear"></div><!--clear floats-->
	</a>
</article>
</div>
<?php if( $i % 4 == 0 ) echo '<div class="clear"></div>'; ?>
<?php
  }
 ?>
	

	</article>
	
</section>

<?php	
	get_footer();