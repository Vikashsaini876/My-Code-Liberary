<form class="searchform" method="get" id="searchform" action="<?php echo home_url(); ?>">
  <input type="text" id="s2" name="s" class="search" placeholder="<?php _e('Type and hit enter...','ebor_starter'); ?>" />
</form>