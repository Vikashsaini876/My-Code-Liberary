<?php 
	get_header();
	
	get_template_part('loop/loop','portfolio');
	
	get_footer();