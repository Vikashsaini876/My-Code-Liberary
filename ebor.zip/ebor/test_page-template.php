<?php
/*
*
*  Template Name: art-work
*
*
*/

get_header();

?>
<section id="content" class="clearfix">
<?php 
$loop = new WP_Query(
array( 
  'post_type'  => 'portfolio',        // only query News post type
  'posts_per_page' => -1,
  'tax_query' => array(
    array(
        'taxonomy'  => 'portfolio-category',
        'field'     => 'slug',
        'terms'     => 'rediscovered-collection', // exclude items media items in the news-cat custom taxonomy
        'operator'  => 'NOT IN')

        ),
   )
);


//Display the contents
  $i = 0;
while ( $loop->have_posts() ) : $loop->the_post();
$url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'full');
	
	/**
	* Now let's crop the image with the aq_resize function, from the aqua resizer found at /ebor_framework/aq_resizer.php
	* We'll return an array to build the image with
	* @return array
	*/
	$image = aq_resize($url[0], 400, 400, 1, false);
	$i++;
?>


<div class="one_fourth <?php if( $i % 4 == 0 ) echo 'last'; ?>">
<article id="portfolio-<?php the_ID(); ?>" <?php post_class(); ?>>
	<a href="<?php the_permalink(); ?>" class="portfolio-index-link">
		<img src="<?php echo $image[0]; ?>" alt="<?php the_title(); ?>" width="<?php echo $image[1]; ?>" height="<?php echo $image[2]; ?>" />
		<?php the_title('<h4 class="portfolio-index-title">','</h4>'); ?>
		<div class="clear"></div><!--clear floats-->
	</a>
</article>
</div>
<?php if( $i % 4 == 0 ) echo '<div class="clear"></div>'; ?>
<?php endwhile;?>

</section>

<?php get_footer();?>