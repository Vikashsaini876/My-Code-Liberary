<?php
include("connection.php");
 if(isset($_POST["login"])){
	 $email=$_POST["email"]; 
	 $password=(md5($_POST["password"]));

$query="select user_email,password from register where user_email='$email' and password='$password'";
$run_query=mysqli_query($conn,$query);
$check=mysqli_num_rows($run_query);
if($check==1){
    header("location:index.php");
}else{
       echo "<h3>Invalid Login Credentials!!!</h3>";
    }
}

?> 
<html>
<body>
<form action="" method="post">
<p>Email:<input type="text" name="email"></p>
<p>Password:<input type="text" name="password"></p>
<input type="submit" name="login" value="Login">
<form>
</body>
</html>