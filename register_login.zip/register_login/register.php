<?php include("connection.php");
 if(isset($_POST["submit"])){
	 $name=$_POST["username"];
	 $email=$_POST["email"];
	 $password=(md5($_POST["password"]));
	 $contact_no=$_POST["contact_no"];

$query="select * from register where user_name='$name' or user_email='$email'";
$run_query=mysqli_query($conn,$query);
$check=mysqli_num_rows($run_query);
if($check>=1){
    echo "<h3 style='color:red'>Username or Email you have entered already registred,Please try another</h3>";
}
else{
    $querry="insert into register(user_name,user_email,password,contact_no)values('$name','$email','$password','$contact_no')";
    $run_querry=mysqli_query($conn,$querry);
    if($run_querry){
        echo "<h3 style='color:green'>You have registered successfully!!!</h3>";
    }
}
 }
?>
<html>
<head>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/ajax.js"></script>
</head>
<body>
<form action="" method="post">
<p>Name:<input type="text" name="username" id="username"></p>
<p>Email:<input type="text" name="email" id="email"></p>
<p>Password:<input type="text" name="password" id="pass"></p>
<p>Contact:<input type="text" name="contact_no" id="contact"></p>
<input type="submit" name="submit" value="Register" id="register">
<div id="result"></div>
<form>
</body>
</html>