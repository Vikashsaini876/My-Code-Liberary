<?php $conn = mysqli_connect("localhost","root","","user_register_login");
 ?>