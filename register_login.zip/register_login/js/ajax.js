$(document).ready(function(){
$("#register").click(function(){
	var username =$("#username").val();
	var user_email =$("#email").val();
	var user_pass =$("#pass").val();
	var user_contact =$("#contact").val();
	
	/*$.post("register.php",{name:username,email:user_email,pass:user_pass,contact:user_contact},function(data){
		$("#result").html(data);
	});*/
	$.ajax({
		url:"register.php",
		data:{name:username,email:user_email,pass:user_pass,contact:user_contact},
		type:"POST",
		success:function(data){
			$("#result").html(data);
		}
	});
});	
	
});