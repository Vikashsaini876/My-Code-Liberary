<?php
// add our customized style and javascript file for divi child theme
	add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles' );
	function theme_enqueue_styles() {
	    wp_enqueue_style( 'divi', get_template_directory_uri() . '/style.css' );
      wp_enqueue_script( 'divi', plugin_dir_url( __FILE__ ) . 'js/scripts.js', array( 'jquery', 'divi-custom-script' ), '0.1.2', true );
	}

	function bp_divitheme_widgets_init() {
	
		// logged in user's sidebar of divi child theme. Area 1, located in the sidebar. Empty by default.
		register_sidebar( array(
				'name'          => 'BP Divi Child User Sidebar',
				'id'            => 'bp-child-divi',
				'description'   => __( 'The sidebar widget area', 'buddypress' ),
				'before_widget' => '<div id="%1$s" class="et_pb_widget %2$s">',
				'after_widget' => '</div> <!-- end .et_pb_widget -->',
				'before_title' => '<h4 class="widgettitle">',
				'after_title' => '</h4>',				
		) );
		// divi child buddypress theme of non-logged in user
		register_sidebar( array(
				'name'          => 'BP Divi Child Guest Sidebar',
				'id'            => 'bp-child-divi-guest',
				'description'   => __( 'The sidebar widget area', 'buddypress' ),
				'before_widget' => '<div id="%1$s" class="et_pb_widget %2$s">',
				'after_widget' => '</div> <!-- end .et_pb_widget -->',
				'before_title' => '<h4 class="widgettitle">',
				'after_title' => '</h4>',
		) );		
	}
	add_action( 'widgets_init', 'bp_divitheme_widgets_init' );
	//this is regular sidebar
	register_sidebar( array(
			'name' => esc_html__( 'Sidebar', 'Divi' ),
			'id' => 'sidebar-1',
			'before_widget' => '<div id="%1$s" class="et_pb_widget %2$s">',
			'after_widget' => '</div> <!-- end .et_pb_widget -->',
			'before_title' => '<h4 class="widgettitle">',
			'after_title' => '</h4>',
	) );

	/*
	 * Detect a user is logged in user or not logged in user 
	 */
	
	function divi_child_theme_logged_alreay($usernow = 0)
	{
		if (empty($usernow))
		{
			$usernow = get_current_user_id();
		}
		
		if (empty($usernow))
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	/*
	 * Add class for divi child theme body
	 */	
	function divi_body_class($classes, $class)
	{
		$bp_current_component_check  = bp_current_component();
		if ($bp_current_component_check == '')
		{
			
		}
		else {		
			$classes = str_ireplace('page-template-page-template-blank-php', '', $classes);			
		}

		if ( is_page_template( 'page-template-community.php' ) ) {
			$classes[] = 'buddypress';
		}
				
		//page-template-page-template-blank-php is dedicated of DIVI theme now.
		return $classes;
	}
	
	
	add_filter( 'body_class', 'divi_body_class',2000,2);
?>