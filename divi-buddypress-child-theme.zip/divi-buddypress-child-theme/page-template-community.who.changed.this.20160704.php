<?php
/*
Template Name: Community Page
*/

get_header();

$is_page_builder_used = et_pb_is_pagebuilder_used( get_the_ID() ); ?>

<div id="main-content">

<?php //if ( ! $is_page_builder_used ) : ?>

	<div class="container">
		<div id="content-area" class="clearfix">
			<div id="left-area">

<?php //endif; ?>

			<?php while ( have_posts() ) : the_post(); ?>

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<?php if ( ! $is_page_builder_used ) : ?>

					<h1 class="main_title"><?php the_title(); ?></h1>
				<?php
					$thumb = '';

					$width = (int) apply_filters( 'et_pb_index_blog_image_width', 1080 );

					$height = (int) apply_filters( 'et_pb_index_blog_image_height', 675 );
					$classtext = 'et_featured_image';
					$titletext = get_the_title();
					$thumbnail = get_thumbnail( $width, $height, $classtext, $titletext, $titletext, false, 'Blogimage' );
					$thumb = $thumbnail["thumb"];

					if ( 'on' === et_get_option( 'divi_page_thumbnails', 'false' ) && '' !== $thumb )
						print_thumbnail( $thumb, $thumbnail["use_timthumb"], $titletext, $width, $height );
				?>

				<?php endif; ?>

					<div class="entry-content">
					<?php
						the_content();
						
						
						//bp_get_options_nav(); we have no way to call this options nav out of BP, but keep this place for the future maybe realize
						//bp_get_template_part( 'members/single/cover-image-header' ); another method to get header image
						$nowuser = get_current_user_id(); // we only need logged in user's record
						if (divi_child_theme_logged_alreay())
						{
						?>
						
						<div id="buddypress" class="divi-child-theme-user-panel">
						
							<?php
						
							/**
							 * Fires before the display of member home content.
							 *
							 * @since 1.2.0
							 */
							do_action( 'bp_before_member_home_content' ); ?>
						
							<div id="item-header" role="complementary">
						
								<?php
								/**
								 * If the cover image feature is enabled, use a specific header
								 */
								//!!! we do not need this method now, but keep this method in here for the feature usage								
								/*
								if ( bp_displayed_user_use_cover_image_header() ) :
								
									bp_get_template_part( 'members/single/cover-image-header' );
								else :
								
									bp_get_template_part( 'members/single/member-header' );
								endif;
								*/

								?>
						
								<?php  do_action( 'bp_before_member_header' ); ?>

<div id="cover-image-container">

	<a id="header-cover-image" href="<?php echo divi_child_bp_get_loggedin_user_link(); //bp_displayed_user_link(); ?>"></a>

	<div id="item-header-cover-image">
		<div id="item-header-avatar">
			<a href="<?php echo divi_child_bp_get_loggedin_user_link(); ?>">

				<?php 
				echo bp_get_loggedin_user_avatar('type=full'); 
				 
				?>

			</a>
		</div><!-- #item-header-avatar -->

		<div id="item-header-content">

			<?php if ( bp_is_active( 'activity' ) && bp_activity_do_mentions() ) : ?>
				<h2 class="user-nicename">@<?php bp_loggedin_user_username();  ?></h2>
			<?php endif; ?>

			<div id="item-buttons"><?php

				/**
				 * Fires in the member header actions section.
				 *
				 * @since 1.2.6
				 */
				do_action( 'bp_member_header_actions' ); ?></div><!-- #item-buttons -->

			<span class="activity"><?php 
			bp_last_activity( $nowuser );
			?></span>
			
			

			<?php

			/**
			 * Fires before the display of the member's header meta.
			 *
			 * @since 1.2.0
			 */
			do_action( 'bp_before_member_header_meta' ); ?>

			<div id="item-meta">

				<?php if ( bp_is_active( 'activity' ) ) : ?>

					<div id="latest-update">

						<?php 
						// !!! we get logged in users lastes updates
						bp_activity_latest_update( $nowuser );
						
						?>

					</div>

				<?php endif; ?>

				<?php

				 /**
				  * Fires after the group header actions section.
				  *
				  * If you'd like to show specific profile fields here use:
				  * bp_member_profile_data( 'field=About Me' ); -- Pass the name of the field
				  *
				  * @since 1.2.0
				  */
				 do_action( 'bp_profile_header_meta' );

				 ?>

			</div><!-- #item-meta -->

		</div><!-- #item-header-content -->

	</div><!-- #item-header-cover-image -->
</div><!-- #cover-image-container -->

<?php

/**
 * Fires after the display of a member's header.
 *
 * @since 1.2.0
 */
do_action( 'bp_after_member_header' ); ?>

<?php

/** This action is documented in bp-templates/bp-legacy/buddypress/activity/index.php */
do_action( 'template_notices' ); 
//!!! end head
?>						
						
						
						
							</div><!-- #item-header -->
						
							<div id="item-nav">
								<div class="item-list-tabs no-ajax" id="object-nav" role="navigation">
									<ul>
						
										<?php 

											divi_child_bp_get_loggedin_user_nav();
				
										?>
						
										<?php
						
										/**
										 * Fires after the display of member options navigation.
										 *
										 * @since 1.2.4
										 */
										do_action( 'bp_member_options_nav' ); 
										?>
						
									</ul>
								</div>
							</div><!-- #item-nav -->
						
							<div id="item-body">
						
								<?php
						
								/**
								 * Fires before the display of member body content.
								 *
								 * @since 1.2.0
								 */
								do_action( 'bp_before_member_body' );
						
								if ( bp_is_user_activity() || !bp_current_component() ) :
									bp_get_template_part( 'members/single/activity' );
								
						
								elseif ( bp_is_user_blogs() ) :
									bp_get_template_part( 'members/single/blogs'    );
						
								elseif ( bp_is_user_friends() ) :
									bp_get_template_part( 'members/single/friends'  );
						
								elseif ( bp_is_user_groups() ) :
									bp_get_template_part( 'members/single/groups'   );
						
								elseif ( bp_is_user_messages() ) :
									bp_get_template_part( 'members/single/messages' );
						
								elseif ( bp_is_user_profile() ) :
									bp_get_template_part( 'members/single/profile'  );
						
								elseif ( bp_is_user_forums() ) :
									bp_get_template_part( 'members/single/forums'   );
						
								elseif ( bp_is_user_notifications() ) :
									bp_get_template_part( 'members/single/notifications' );
						
								elseif ( bp_is_user_settings() ) :
									bp_get_template_part( 'members/single/settings' );
						
								// If nothing sticks, load a generic template
								else :
									bp_get_template_part( 'members/single/plugins'  );
						
								endif;
								/**
								 * Fires after the display of member body content.
								 *
								 * @since 1.2.0
								 */
								do_action( 'bp_after_member_body' ); ?>
						
							</div><!-- #item-body -->
						
							<?php
						
							/**
							 * Fires after the display of member home content.
							 *
							 * @since 1.2.0
							 */
							do_action( 'bp_after_member_home_content' ); ?>
							</div><!-- #buddypress -->
							
							<?php 
						}						

						if ( ! $is_page_builder_used )
							wp_link_pages( array( 'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'Divi' ), 'after' => '</div>' ) );
					?>
					</div> <!-- .entry-content -->

				<?php
					if ( ! $is_page_builder_used && comments_open() && 'on' === et_get_option( 'divi_show_pagescomments', 'false' ) ) comments_template( '', true );
				?>

				</article> <!-- .et_pb_post -->

			<?php endwhile; ?>

<?php if ( ! $is_page_builder_used ) 
{ ?>

			</div> <!-- #left-area -->

			<?php 
			
			//get_sidebar(); 
			echo '<div id="sidebar">';
			if (divi_child_theme_logged_alreay())
			{
				dynamic_sidebar('bp-child-divi');
			}
			else
			{
				//!!! old miss-understading requirement -- dynamic_sidebar('bp-child-divi-guest');
				dynamic_sidebar('bp-child-divi');
			}
			echo "</div>";			
			?>
		</div> <!-- #content-area -->
	</div> <!-- .container -->

<?php }
		else
		{
			?>
			</div> <!-- #left-area -->
			<?php 
			echo '<div id="sidebar">';
			if (divi_child_theme_logged_alreay())
			{
				dynamic_sidebar('bp-child-divi');
			}
			else
			{
				//!!! miss-understaing codes dynamic_sidebar('bp-child-divi-guest');
				dynamic_sidebar('bp-child-divi');
			}			
			echo "</div>";
		}

?>

</div> <!-- #main-content -->

<?php get_footer(); ?>
<?php 
//!!!
/**
 * Output the email address of the displayed user.
 */
function divi_child_bp_displayed_user_email() {
	echo divi_child_bp_get_displayed_user_email();
}
/**
 * Get the email address of the displayed user.
 *
 * @return string
 */
function divi_child_bp_get_displayed_user_email() {
	$bp = buddypress();

	// If displayed user exists, return email address.
	if ( isset( $bp->displayed_user->userdata->user_email ) )
		$retval = $bp->displayed_user->userdata->user_email;
	else
		$retval = '';

	/**
	 * Filters the email address of the displayed user.
	 *
	 * @since 1.5.0
	 *
	 * @param string $retval Email address for displayed user.
	 */
	return apply_filters( 'bp_get_displayed_user_email', esc_attr( $retval ) );
}

/**
 * Output the "active [x days ago]" string for a user.
 *
 * @see bp_get_last_activity() for a description of parameters.
 *
 * @param int $user_id See {@link bp_get_last_activity()}.
 */

/**
 * Output the calculated first name of the displayed or logged-in user.
 */
function divi_child_bp_user_firstname() {
	echo divi_child_bp_get_user_firstname();
}
/**
 * Output the first name of a user.
 *
 * Simply takes all the characters before the first space in a name.
 *
 * @param string|bool $name Full name to use when generating first name.
 *                          Defaults to displayed user's first name, or to
 *                          logged-in user's first name if it's unavailable.
 * @return string
 */
function divi_child_bp_get_user_firstname( $name = false ) {

	// Try to get displayed user.
	if ( empty( $name ) )
		$name = divi_child_bp_get_displayed_user_fullname();

	// Fall back on logged in user.
	if ( empty( $name ) )
		$name = divi_child_bp_get_loggedin_user_fullname();

	$fullname = (array) explode( ' ', $name );

	/**
	 * Filters the first name of a user.
	 *
	 * @since 1.2.0
	 *
	 * @param string $value    First name of user.
	 * @param string $fullname Full name of user.
	*/
	return apply_filters( 'bp_get_user_firstname', $fullname[0], $fullname );
}

/**
 * Output the link for the logged-in user's profile.
 */
function divi_child_bp_loggedin_user_link() {
	echo divi_child_bp_get_loggedin_user_link();
}
/**
 * Get the link for the logged-in user's profile.
 *
 * @return string
 */
function divi_child_bp_get_loggedin_user_link() {

	/**
	 * Filters the link for the logged-in user's profile.
	 *
	 * @since 1.2.4
	 *
	 * @param string $value Link for the logged-in user's profile.
	 */
	return apply_filters( 'bp_get_loggedin_user_link', divi_child_bp_loggedin_user_domain() );
}

/**
 * Output the link for the displayed user's profile.
 */
function divi_child_bp_displayed_user_link() {
	echo divi_child_bp_get_displayed_user_link();
}
/**
 * Get the link for the displayed user's profile.
 *
 * @return string
 */
function divi_child_bp_get_displayed_user_link() {

	/**
	 * Filters the link for the displayed user's profile.
	 *
	 * @since 1.2.4
	 *
	 * @param string $value Link for the displayed user's profile.
	 */
	return apply_filters( 'bp_get_displayed_user_link', divi_child_bp_displayed_user_domain() );
}

/**
 * Alias of {@link bp_displayed_user_domain()}.
 *
 * @deprecated
 */
function divi_child_bp_user_link() { divi_child_bp_displayed_user_domain(); }

/**
 * Alias of {@link bp_displayed_user_id()}.
 */
function divi_child_bp_current_user_id() { return divi_child_bp_displayed_user_id(); }

/**
 * Generate the link for the displayed user's profile.
 *
 * @return string
 */
function divi_child_bp_displayed_user_domain() {
	$bp = buddypress();

	/**
	 * Filters the generated link for the displayed user's profile.
	 *
	 * @since 1.0.0
	 *
	 * @param string $value Generated link for the displayed user's profile.
	*/
	return apply_filters( 'bp_displayed_user_domain', isset( $bp->displayed_user->domain ) ? $bp->displayed_user->domain : '' );
}

/**
 * Generate the link for the logged-in user's profile.
 *
 * @return string
 */
function divi_child_bp_loggedin_user_domain() {
	$bp = buddypress();

	/**
	 * Filters the generated link for the logged-in user's profile.
	 *
	 * @since 1.0.0
	 *
	 * @param string $value Generated link for the logged-in user's profile.
	*/
	return apply_filters( 'bp_loggedin_user_domain', isset( $bp->loggedin_user->domain ) ? $bp->loggedin_user->domain : '' );
}

/**
 * Output the displayed user's display name.
 */
function divi_child_bp_displayed_user_fullname() {
	echo divi_child_bp_get_displayed_user_fullname();
}
/**
 * Get the displayed user's display name.
 *
 * @return string
 */
function divi_child_bp_get_displayed_user_fullname() {
	$bp = buddypress();

	/**
	 * Filters the displayed user's display name.
	 *
	 * @since 1.2.0
	 *
	 * @param string $value Displayed user's display name.
	*/
	return apply_filters( 'bp_displayed_user_fullname', isset( $bp->displayed_user->fullname ) ? $bp->displayed_user->fullname : '' );
}

/**
 * Alias of {@link bp_get_displayed_user_fullname()}.
 */
function divi_child_bp_user_fullname() { echo divi_child_bp_get_displayed_user_fullname(); }


/**
 * Output the logged-in user's display name.
 */
function divi_child_bp_loggedin_user_fullname() {
	echo divi_child_bp_get_loggedin_user_fullname();
}
/**
 * Get the logged-in user's display name.
 *
 * @return string
 */
function divi_child_bp_get_loggedin_user_fullname() {
	$bp = buddypress();

	/**
	 * Filters the logged-in user's display name.
	 *
	 * @since 1.0.0
	 *
	 * @param string $value Logged-in user's display name.
	*/
	return apply_filters( 'bp_get_loggedin_user_fullname', isset( $bp->loggedin_user->fullname ) ? $bp->loggedin_user->fullname : '' );
}

/**
 * Output the username of the displayed user.
 */
function divi_child_bp_displayed_user_username() {
	echo divi_child_bp_get_displayed_user_username();
}
/**
 * Get the username of the displayed user.
 *
 * @return string
 */
function divi_child_bp_get_displayed_user_username() {
	$bp = buddypress();

	if ( bp_displayed_user_id() ) {
		$username = bp_core_get_username( bp_displayed_user_id(), $bp->displayed_user->userdata->user_nicename, $bp->displayed_user->userdata->user_login );
	} else {
		$username = '';
	}

	/**
	 * Filters the username of the displayed user.
	 *
	 * @since 1.2.0
	 *
	 * @param string $username Username of the displayed user.
	 */
	return apply_filters( 'bp_get_displayed_user_username', $username );
}


/**
 * Render the navigation markup for the logged-in user.
 *
 * Each component adds to this navigation array within its own
 * [component_name]setup_nav() function.
 *
 * This navigation array is the top level navigation, so it contains items such as:
 *      [Blog, Profile, Messages, Groups, Friends] ...
 *
 * The function will also analyze the current component the user is in, to
 * determine whether or not to highlight a particular nav item.
 *
 * @todo Move to a back-compat file?
 * @deprecated Does not seem to be called anywhere in BP core.
 */
function divi_child_bp_get_loggedin_user_nav() {
	$bp = buddypress();

	// Loop through each navigation item.
	foreach( (array) $bp->bp_nav as $nav_item ) {
		$selected = '';
//var_dump('1003');
//var_dump($bp);
		// If the current component matches the nav item id, then add a highlight CSS class.
		if ( !bp_is_directory() && !empty( $bp->active_components[bp_current_component()] ) && $bp->active_components[bp_current_component()] == $nav_item['css_id'] ) {
			$selected = ' class="current selected"';
		}

		// If we are viewing another person (current_userid does not equal
		// loggedin_user->id then check to see if the two users are friends.
		// if they are, add a highlight CSS class to the friends nav item
		// if it exists.
		if ( !bp_is_my_profile() && bp_displayed_user_id() ) {
			$selected = '';

			if ( bp_is_active( 'friends' ) ) {
				if ( $nav_item['css_id'] == $bp->friends->id ) {
					if ( friends_check_friendship( bp_loggedin_user_id(), bp_displayed_user_id() ) ) {
						$selected = ' class="current selected"';
					}
				}
			}
		}

		// Echo out the final list item.
		echo apply_filters_ref_array( 'bp_get_loggedin_user_nav_' . $nav_item['css_id'], array( '<li id="li-nav-' . $nav_item['css_id'] . '" ' . $selected . '><a id="my-' . $nav_item['css_id'] . '" href="' . $nav_item['link'] . '">' . $nav_item['name'] . '</a></li>', &$nav_item ) );
	}

	// Always add a log out list item to the end of the navigation.
	$logout_link = '<li><a id="wp-logout" href="' .  wp_logout_url( bp_get_root_domain() ) . '">' . __( 'Log Out', 'buddypress' ) . '</a></li>';

	echo apply_filters( 'bp_logout_nav_link', $logout_link );
}


?>