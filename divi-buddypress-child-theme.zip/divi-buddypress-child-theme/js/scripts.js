jQuery(document).ready(function ($) {
  // Code Here
});