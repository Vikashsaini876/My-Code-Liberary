<?php
/* 
// Start all customized header section in here
// The first section is for php codes for example the next code section will add a customized logo
?>
		<header id="main-header" class="main-customized-header" data-height-onload="<?php echo esc_attr( et_get_option( 'menu_height', '66' ) ); ?>">
			<div class="container clearfix et_menu_container">
			<?php
				$logo = ( $user_logo = et_get_option( 'divi_logo' ) ) && '' != $user_logo
					? $user_logo
					: $template_directory_uri . '/images/logo.png';
			?>
<?php 
// Start logo section from here
?>
				<div class="logo_container customized_logo_container">
					<span class="logo_helper"></span>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>">
						<img src="<?php echo esc_attr( $logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" id="logo" data-height-percentage="<?php echo esc_attr( et_get_option( 'logo_height', '54' ) ); ?>" />
					</a>
				</div>
				
			</div> <!-- .container -->
<?php 
// End logo section from here
// End customized logo example of php code section
// Next is Html Code sections, for example Start Customized Head Content
 * 
 */
		//echo '<div id="image-2" class="et_pb_widget widget_image">';
		//echo '<h4 class="widgettitle">       Home Page</h4>';
		//echo '<div class="jetpack-image-container">';
		//echo '<a href="http://personal-longevity.com/subscriptions/private-members/">';
		//echo '<img src="http://personal-longevity.com/subscriptions/wp-content/uploads/2016/03/home-button.jpe" class="aligncenter" width="50" height="50">';
		//echo '</a>';
		//echo '</div>';
		//echo '</div>';
?>
		<header id="main-header" class="main-customized-header" data-height-onload="<?php echo esc_attr( et_get_option( 'menu_height', '66' ) ); ?>">
			
			<div class="customize_head_content_wrap">
				<div class="container customize_head_content">
					
						
							<div class="customize_head_item">
									<?php $siteurl = get_option('siteurl');  ?>
									<a href="<?php echo $siteurl; ?>">
										<div>
											<img src="<?php echo $siteurl; ?>/wp-content/uploads/2016/03/home-button.jpe" class="aligncenter bp_customized_home_icon" width="50" height="50">
											<h1 class='bp_customized_home_text' style="text-align: center;">Longevity Community Groups and Discussions</h1>
										</div>
										<div class='bpclearboth'></div>
									</a>
								
							</div> <!-- .customize_head_item -->			
						

				</div><!-- .customize_head_content -->
			</div>

<?php // End Customized Head Content ?>
		</header> <!-- #main-header -->
<?php 
// End all customized header section in here
?>
		<div id="et-main-area">