<?php

if ( ( is_single() || is_page() ) && 'et_full_width_page' === get_post_meta( get_queried_object_id(), '_et_pb_page_layout', true ) )
	return;


$bp_current_component_check  = bp_current_component();
if ($bp_current_component_check == '')
{

	if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
			<div id="sidebar">
				<?php dynamic_sidebar( 'sidebar-1' ); ?>
			</div> <!-- end #sidebar -->
		<?php endif; ?>	
<?php 		
}
else
{
	?>

	<div id="sidebar">
					<?php 
					if (divi_child_theme_logged_alreay())
					{
						dynamic_sidebar('bp-child-divi');
					}
					else
					{
						//!!! old good codes dynamic_sidebar('bp-child-divi-guest');
						dynamic_sidebar('bp-child-divi');
					}
					//dynamic_sidebar( 'sidebar-1' );
					?>
				</div> <!-- end #sidebar -->	
<?php 	
}
/*
if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
	<div id="sidebar">
		<?php dynamic_sidebar( 'sidebar-1' ); ?>
	</div> <!-- end #sidebar -->
<?php endif; ?>

*/