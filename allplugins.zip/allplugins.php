<?php 
echo 
"Newsletter
Login LockDown
Toolset Types
Toolset Types
Instagram Feed
Instagram Feed
AddToAny Share Buttons
YITH WooCommerce Wishlist
YITH WooCommerce Ajax Search
YITH WooCommerce Ajax Price Filter
YITH WooCommerce Ajax Product Filter
TablePress
The Events Calendar
Meta Slider
Revolution Slider
WordPress Importer
Wordfence Security
Advanced Custom Fields
Really Simple CAPTCHA
NextGEN Gallery
Unite Gallery
File Manager
Visual Composer
WP Google Maps
Sticky Header
Wonder Crousel Plugin
Envira Gallery Plugin
UpdraftPlus WordPress Backup Plugin
Slideshow
Easy Facebook Likebox
Add To Any
Anything Popup
Contact Form 7
WPtouch Mobile Plugin
Social Share
Imsanity-Image Optimizer
Social Media Feather | social media sharing
YouTube
WooCommerce
Social Media and Share Icons (Ultimate Social Media)
Use Any Font
Events Manager
Feed Them Social - Facebook, Instagram, Twitter, Vine, Pinterest, etc
Shortcodes Ultimate
Accordion Plugin
Tabs Plugin
Advanced Custom Fields Repeater & Flexible Content Fields Collapser
Protect Your Admin
YITH WooCommerce Compare
All 404 Redirect to Homepage
Google Language Translator
CountDown Pro WP Plugin - WebSites/Products/Offers
Master Slider - Responsive Touch Slider
Live Chat Plugin
Ultimate Member
WooCommerce PayPal Express Checkout Payment Gateway
WooCommerce Stripe Payment Gateway-Credit Card
All-in-One Event Calendar
Hide Single Title";
?>