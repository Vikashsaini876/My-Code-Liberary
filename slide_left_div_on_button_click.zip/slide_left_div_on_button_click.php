<div class="inner_page_text" id="disclaimer_textt"><?php dynamic_sidebar('Inner Pages Pop Up Text'); ?></div>
<div class="inner_page_img" id="slide_rightt"><?php echo "<img src='http://www.zenithitservice.com/wp-content/uploads/2016/11/disclaimer.png'>";?></div>

.homepage_page_text{
/*  float:left;
 width:450px;
 display:none;
 color:#fff;
 background-color:#024977;
 padding:20px;
 word-spacing:2px;
 position:relative;
 position:absolute;
 z-index:9999;
  */
 background: #024977;
 margin: 0px 0 0 -335px;
 position: absolute;
 width: 335px;
 z-index: 9999;
 padding: 10px;
 color:#fff;
}
.homepage_page_img{
 position:absolute;
 z-index:9999;
}


<script type="text/javascript">
	$lm = jQuery.noConflict();
	$lm(document).ready(function(){
		$lm("#slide_rightt").toggle(function() {$lm("#disclaimer_textt").animate({"left": "+=335px", "opacity" : "1"}, "slow");
			$lm("#slide_rightt").animate({"left": "+=335px", "opacity" : "1"}, "slow");
			var checker='out';
		}, function() {
			$lm("#disclaimer_textt").animate({"left": "-=335px", "opacity" : "1"}, "slow");
			$lm("#slide_rightt").animate({"left": "-=335px", "opacity" : "1"}, "slow");
			var checker='in';
		});
	});
	</script> "