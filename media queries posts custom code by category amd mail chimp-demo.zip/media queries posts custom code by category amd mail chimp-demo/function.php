<?php
/*
Author: Nick Jeffers
@version: 4.1
@url: http://www.websitesdepot.com
@copyright: 2015 Websites Depot Inc

*/


function theme_enqueue_styles() {

    if( function_exists('wd_scripts_in_footer')) {
        $footer = wd_scripts_in_footer();
    } else {
        $footer = false;
    }

    wp_enqueue_style('compiled', get_stylesheet_directory_uri() . '/includes/css/compiled.css', array('bootstrap', 'font-awesome'));
    wp_enqueue_style( 'child-css', get_stylesheet_directory_uri() . '/style.css', array('compiled') );

    wp_enqueue_script('compiled', get_stylesheet_directory_uri() . '/includes/js/compiled.js', array('jquery'), '', $footer);
    wp_enqueue_script('child-js', get_stylesheet_directory_uri() . '/includes/js/child.js', array('compiled'), '', $footer);

}

add_action( 'wp_enqueue_scripts', 'theme_enqueue_styles', 11 );

/* ADD YOUR STUFF BELOW */

register_sidebar( array( 'name' =>'Footer Menu', 'id' => 'footer-menu', 'before_widget' => '
', 'after_widget' => '
', 'before_title' => '', 'after_title' => '', ) );

function custom_recent_posts_shortcode($atts){
 $loop = new WP_Query(
     array( 'orderby' => 'date', 'posts_per_page' => '4','post_status' => 'publish','order'=>'DESC' )
 );

$list = '<div class="home-posts">';
?>
<div class="row">
<?php
while($loop->have_posts()) : $loop->the_post();

$pt_Id = get_the_ID();

$feat_img = get_the_post_thumbnail( $pt_Id, 'medium' );

 $list .= '<div class="col-md-3"><div class="home-posts-block"><div class="fet-image">' . $feat_img  . ' </div>'. '<h3><a href="' . get_permalink() . '">' . get_the_title() . '</a></h3><div class="red-more"><p class="pst_excrpt">' . substr(get_the_excerpt(), 0,150) . ' ... </p><p class="pst_excrpt"><a href="' . get_permalink() . '">' . 'Read More' . '</a></p></div></div></div>';

endwhile;

wp_reset_query();
?>
</div>
<?php
return $list . '</div>';

}

add_shortcode('recent-posts', 'custom_recent_posts_shortcode');

function call_nav_menu_on_footer(){
	
register_nav_menus( array(
	'footer_menu' => 'Footer Menu',
) );

}
return call_nav_menu_on_footer();

add_shortcode('foot-menu', 'call_nav_menu_on_footer');

