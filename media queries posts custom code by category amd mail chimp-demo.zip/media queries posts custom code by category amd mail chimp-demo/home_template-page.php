<?php
/**
 * Template Name: Home
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
global $wd_all_page_meta;
//wd_test($wd_all_page_meta);

do_action( 'wd_page_before_modules' );

foreach($module_array as $module) {
    if ($module > 1) { // All modules that aren't the standard content
        echo wd_get_module($module);
    } else { // pull the page content


				/*********
				 * Name: wd_core_content_head
				 * Type: Function
				 * Location: /includes/functions/wd_functions.php
				 **********/
					 
				wd_core_content_head($fullwidth = false);
			
				get_template_part('left-sidebar'); ?>

                <main id="main" class="site-main col-md-<?php echo $wd_all_page_meta['core-width']; ?> <?php if($wd_all_page_meta['number_of_sidebars']){echo 'has_sidebar';} ?>" role="main">

					<?php do_action( 'wd_main_section_before' ); ?>
						<div class="hm-section">
	<?php echo do_shortcode( '[advps-slideshow optset="4"]' );?>
	<section class="main-role-sec">
	<section class="adv_pppr">
						<div class="advertising">
						<a href="<?php echo site_url('/category/advertising/'); ?>"><h1 class="hm-title_heading_main">Advertising</h1></a>
						<div class="col-md-6">
<?php
$args1 = array( 'posts_per_page' => 1, 'category' =>6);

$myposts1 = get_posts( $args1 );
$myposts1[0]->post_title;
$dtt = $myposts1[0]->post_date;

  $originalDate = $dtt;
$newDate = date("d-m-Y", strtotime($originalDate));


 $feat_img = get_the_post_thumbnail($myposts1[0]->ID, 'thumbnail' );


		?>
		<div class="hm-img"><?php echo $feat_img; ?></div>
		
<h3><a href="<?php echo get_permalink(); ?>"><?php echo  $myposts1[0]->post_title; ?></a></h3>
<span><?php echo $newDate;?></span>    <span class="auth"><?php echo get_the_author(); ?></span>

<div class="excrt">
<p><?php $content = $myposts1[0]->post_content;
               $content = strip_tags($content);
               echo substr($content, 0, 150); echo "..."?></p>
 
</div>
<?php wp_reset_query();	?>
						</div>
									

						
						<div class="col-md-6">
						<?php 
						 $args = array( 'posts_per_page' => 5, 'offset'=> 1, 'category' => 6 );

$myposts = get_posts( $args );
foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
 <h4>
  <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
 </h4>
<?php endforeach; 
wp_reset_postdata();?>
						
						
						
						</div>
						</div>
						<hr>
						<div class="clearfix"></div>	
				<div class="health">		
	<a href="<?php echo site_url('category/health-and-wellness/'); ?>"><h1 class="hm-title_heading_main">Health and Wellness</h1></a>
	<div class="col-md-6">
						<?php
$args1 = array( 'posts_per_page' => 1, 'category' =>11);

$myposts1 = get_posts( $args1 );
$myposts1[0]->post_title;
$dtt = $myposts1[0]->post_date;

  $originalDate = $dtt;
$newDate = date("d-m-Y", strtotime($originalDate));


 $feat_img = get_the_post_thumbnail($myposts1[0]->ID, 'thumbnail' );


		?>
		<div class="hm-img"><?php echo $feat_img; ?></div>
		
<h3><a href="<?php echo get_permalink(); ?>"><?php echo  $myposts1[0]->post_title; ?></a></h3>
<span><?php echo $newDate;?></span>    <span class="auth"><?php echo get_the_author(); ?></span>

<div class="excrt">
<p><?php $content = $myposts1[0]->post_content;
               $content = strip_tags($content);
               echo substr($content, 0, 150); echo "..."?></p>
 
</div>
<?php wp_reset_query();	?>
						</div>
									

						
						<div class="col-md-6">
						<?php 
						 $args = array( 'posts_per_page' => 5, 'offset'=> 1, 'category' => 11 );

$myposts = get_posts( $args );
foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
 <h4>
  <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
 </h4>
<?php endforeach; 
wp_reset_postdata();?>
						
						
						
						</div>
						</div>
						</section>
						<hr>
						<div class="clearfix"></div>	
						<div class="paper">
		<a href="<?php echo site_url('/category/paperweights/'); ?>"><h1 class="hm-title_heading_main">Paper Weights</h1></a>
	<?php echo do_shortcode( '[wp_posts_carousel template="compact.css" post_types="post" all_items="10" show_only="id" exclude="" posts="" ordering="asc" categories="6" relation="and" tags="" show_title="true" show_created_date="true" show_description="excerpt" allow_shortcodes="false" show_category="false" show_tags="false" show_more_button="false" show_featured_image="true" image_source="medium" image_height="100" image_width="100" items_to_show_mobiles="1" items_to_show_tablets="2" items_to_show="3" slide_by="1" margin="5" loop="true" stop_on_hover="true" auto_play="true" auto_play_timeout="1200" auto_play_speed="800" nav="true" nav_speed="800" dots="true" dots_speed="800" lazy_load="false" mouse_drag="true" mouse_wheel="true" touch_drag="true" easing="linear" auto_height="true" custom_breakpoints=""]' );?>
	
</div>
<hr>
<div class="clearfix"></div>	

<section class="mar_bus_but">
						<div class="marketing">
						<div class="col-md-4">
						<a href="<?php echo site_url('/category/marketing/'); ?>"><h1 class="hm-title_heading_main">Marketing</h1></a>
						<?php
$args1 = array( 'posts_per_page' => 1, 'category' =>13);

$myposts1 = get_posts( $args1 );
$myposts1[0]->post_title;
$dtt = $myposts1[0]->post_date;

  $originalDate = $dtt;
$newDate = date("d-m-Y", strtotime($originalDate));


 $feat_img = get_the_post_thumbnail($myposts1[0]->ID, 'thumbnail' );


		?>
		<div class="hm-img"><?php echo $feat_img; ?></div>
		
<h3><a href="<?php echo get_permalink(); ?>"><?php echo  $myposts1[0]->post_title; ?></a></h3>
<span><?php echo $newDate;?></span>    <span class="auth"><?php echo get_the_author(); ?></span>

<div class="excrt">
<p><?php $content = $myposts1[0]->post_content;
               $content = strip_tags($content);
               echo substr($content, 0, 150); echo "..."?></p>
 
</div>
<?php wp_reset_query();	?>
						
						<hr>
						<div class="clearfix"></div>
						
						
						<?php 
						 $args = array( 'posts_per_page' => 5, 'offset'=> 1, 'category' => 13 );

$myposts = get_posts( $args );
foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
 <h4>
  <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
 </h4>
<?php endforeach; 
wp_reset_postdata();?>
						
						
						
						
						</div>
						</div>

						<div class="business">
						<div class="col-md-4">
						<a href="<?php echo site_url('/category/business/'); ?>"><h1 class="hm-title_heading_main">Business</h1></a>

						<?php
$args1 = array( 'posts_per_page' => 1, 'category' =>8);

$myposts1 = get_posts( $args1 );
$myposts1[0]->post_title;
$dtt = $myposts1[0]->post_date;

  $originalDate = $dtt;
$newDate = date("d-m-Y", strtotime($originalDate));


 $feat_img = get_the_post_thumbnail($myposts1[0]->ID, 'thumbnail' );


		?>
		<div class="hm-img"><?php echo $feat_img; ?></div>
		
<h3><a href="<?php echo get_permalink(); ?>"><?php echo  $myposts1[0]->post_title; ?></a></h3>
<span><?php echo $newDate;?></span>    <span class="auth"><?php echo get_the_author(); ?></span>

<div class="excrt">
<p><?php $content = $myposts1[0]->post_content;
               $content = strip_tags($content);
               echo substr($content, 0, 150); echo "..."?></p>
 
</div>
<?php wp_reset_query();	?>
						
						<hr>
						<div class="clearfix"></div>
						
						
						<?php 
$args = array( 'posts_per_page' => 5, 'offset'=> 1, 'category' => 8 );

$myposts = get_posts( $args );
foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
 <h4>
  <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
 </h4>
<?php endforeach; 
wp_reset_postdata();?>
						
						
						
						
						</div>
						</div>
						
						
						
						<div class="beauty-products">
						<div class="col-md-4">
						<a href="<?php echo site_url('/category/beauty-products/'); ?>"><h1 class="hm-title_heading_main">Beauty Products</h1></a>

						<?php
$args1 = array( 'posts_per_page' => 1, 'category' =>7);

$myposts1 = get_posts( $args1 );
$myposts1[0]->post_title;
$dtt = $myposts1[0]->post_date;

  $originalDate = $dtt;
$newDate = date("d-m-Y", strtotime($originalDate));

 $feat_img = get_the_post_thumbnail($myposts1[0]->ID, 'thumbnail' );


		?>
		<div class="hm-img"><?php echo $feat_img; ?></div>
		
<h3><a href="<?php echo get_permalink(); ?>"><?php echo  $myposts1[0]->post_title; ?></a></h3>
<span><?php echo $newDate;?></span>    <span class="auth"><?php echo get_the_author(); ?></span>

<div class="excrt">
<p><?php $content = $myposts1[0]->post_content;
               $content = strip_tags($content);
               echo substr($content, 0, 150); echo "..."?></p>
 
</div>
<?php wp_reset_query();	?>
						
						<hr>
						<div class="clearfix"></div>
						
						
						<?php 
$args = array( 'posts_per_page' => 5, 'offset'=> 1, 'category' => 7 );

$myposts = get_posts( $args );
foreach ( $myposts as $post ) : setup_postdata( $post ); ?>
 <h4>
  <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
 </h4>
<?php endforeach; 
wp_reset_postdata();?>

						
						
						
						</div>
						</div>
						</section>



</section>








</div>
						
					<?php do_action( 'wd_main_section_after' ); ?>

                </main>

                <?php get_template_part('right-sidebar');
				
			
				/*********
				 * Name: wd_core_content_foot
				 * Type: Function
				 * Location: /includes/functions/wd_functions.php
				 **********/
				 				
				wd_core_content_foot();
			
    }
}
get_footer();
